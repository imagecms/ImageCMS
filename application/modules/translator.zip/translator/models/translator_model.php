<?php

/**
 * @property CI_DB_active_record $db
 * @property DX_Auth $dx_auth
 */
class Module_frame_model extends CI_Model {

    function __construct() {
        parent::__construct();
    }

}

?>
