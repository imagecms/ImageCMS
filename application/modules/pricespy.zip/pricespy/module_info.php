<?php

if (!defined('BASEPATH'))
    exit('No direct script access allowed');

$com_info = array(
    'menu_name' => 'Модуль слежения за ценой',
    'description' => '',
    'admin_type' => 'window',
    'window_type' => 'xhr',
    'w' => 600,
    'h' => 550,
    'version' => '1.0b',
    'author' => 'a.gula@imagecms.net'
);

/* End of file module_info.php */
