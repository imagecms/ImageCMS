<?php
$lang['ut_test_name']		= 'Имя теста';
$lang['ut_test_datatype']	= 'Тестируемый тип данных ';
$lang['ut_res_datatype']	= 'Ожидаемый тип данных';
$lang['ut_result']			= 'Результат';
$lang['ut_undefined']		= 'Имя теста неопределено';
$lang['ut_file']			= 'Имя файла';
$lang['ut_line']			= 'Номер строки';
$lang['ut_passed']			= 'Пройден';
$lang['ut_failed']			= 'Не пройден';
// не уверен, что стоит вообще переводить типы данных
$lang['ut_boolean']			= 'boolean';
$lang['ut_integer']			= 'integer';
$lang['ut_float']			= 'float';
$lang['ut_double']			= 'double'; // can be the same as float
$lang['ut_string']			= 'string';
$lang['ut_array']			= 'array';
$lang['ut_object']			= 'object';
$lang['ut_resource']		= 'resource';
$lang['ut_null']			= 'null';