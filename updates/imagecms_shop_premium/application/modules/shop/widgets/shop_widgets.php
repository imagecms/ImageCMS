<?php

class Shop_widgets extends ShopController {

    private $productsDefaults = array(
        'subpath' => 'widgets',
        'productsType' => 'popular',
        'productsCount' => 10,
        'title' => 'Popular products'
    );
    private $brandsDefaults = array(
        'subpath' => 'widgets',
        'brandsCount' => 15,
        'withImages' => true
    );
    private $similarDefaults = array(
        'title' => 'Похожие товары',
        'productsCount' => 5,
        'subpath' => 'widgets'
    );
    private $viewProductDefaults = array('subpath' => 'widgets');

    //featured products
    public function __construct() {
        parent::__construct();
    }

    public function view_product($widget) {

        $settings = $widget['settings'];
        $core_data = $this->core->core_data;
        if ($core_data['data_type'] == 'product')
            $this->addProduct($core_data['id'], $settings['productsCount']);
        $data = array(
            'products' => $this->showLastProducts(),
            'title' => $settings['title']);

        return $this->template->fetch('widgets/' . $widget['name'], $data);
    }

    public function addProduct($param = NULL, $limit = 4) {
        /**
         * Добавление первого продукта в массив.
         */
        if ($param != NULL) {
            if ($this->session->userdata('page') == false) {
                $pageId = array($param);
                $this->session->set_userdata('page', $pageId);
            } else {
                /**
                 * Если не существует такого продукта записываем новый, и удаляем последний.
                 */
                $pageId = $this->session->userdata('page');
                if (count($pageId) >= $limit)
                    array_shift($pageId);

                array_push($pageId, $param);
                $this->session->set_userdata('page', $pageId);
            }
        } else {
            log_message('error', 'Widget function "addProduct" product ID is not passed.');
            return false;
        }
    }

    /**
     * Вывод продукта.
     */
    public function showLastProducts() {
        /**
         * Вызываем сессию и извлекаем из нее все идентификаторы, и записываем в строку через запятую.
         */
        $pageId = $this->session->userdata('page');

        if (count($pageId) > 1) {
            array_pop($pageId);

            /**
             * Вытаскиваем все продукты из базы данных.
             */
            $model = SProductsQuery::create()
                    ->joinWithI18n(MY_Controller::getCurrentLocale())
                    ->filterById($pageId)
                    ->limit(20)
                    ->addAsColumn("newOrder", 'CASE
                        WHEN ' . SProductsPeer::ID . ' = "' . $pageId[0] . '" THEN 0
                        WHEN ' . SProductsPeer::ID . ' = "' . $pageId[1] . '" THEN 1
                        WHEN ' . SProductsPeer::ID . ' = "' . $pageId[2] . '" THEN 2
                        WHEN ' . SProductsPeer::ID . ' = "' . $pageId[3] . '" THEN 3
                        WHEN ' . SProductsPeer::ID . ' = "' . $pageId[4] . '" THEN 4
                        ELSE 100
                        END')
                    ->addAscendingOrderByColumn('newOrder')
                    ->filterByActive(true)
                    ->find();
            /**
             * Возвращаем все продукты в виде массива.
             */
            return $model;
        }
    }

    public function view_product_configure($mode = 'install_defaults', $data = array()) {
        if ($this->dx_auth->is_admin() == FALSE)
            exit;

        switch ($mode) {
            case 'install_defaults':
                $this->load->module('admin/widgets_manager')->update_config($data['id'], $this->viewProductDefaults);
                break;

            case 'show_settings':
                $this->render('view_product_form', array('widget' => $data));
                break;

            case 'update_settings':

                $this->load->library('form_validation');
                $this->form_validation->set_rules('title', 'Заголовок виджета', 'trim|xss_clean');

                if ($this->form_validation->run()) {

                    $settings = array(
                        'productsType' => $this->input->post('productsType'),
                        'title' => $this->input->post('title'),
                        'productsCount' => $this->input->post('productsCount'),
                        'subpath' => 'widgets'
                    );

                    $this->load->module('admin/widgets_manager')->update_config($data['id'], $settings);
                    showMessage('Сохранение прошло успешно');

                    if ($this->input->post('action') == 'tomain')
                        pjax('/admin/widgets_manager');
                    else
                        pjax('');
                }
                else
                    showMessage($this->form_validation->error_string(), '', 'r');

                break;

            default :
                return false;
                break;
        }
    }

    public function products($widget) {

        $settings = $widget['settings'];

        $data = array(
            'products' => getPromoBlock($settings['productsType'], $settings['productsCount']),
            'title' => $settings['title']);


        return $this->template->fetch('widgets/' . $widget['name'], $data);
    }

    public function products_configure($mode = 'install_defaults', $data = array()) {
        if ($this->dx_auth->is_admin() == FALSE)
            exit;

        switch ($mode) {
            case 'install_defaults':
                $this->load->module('admin/widgets_manager')->update_config($data['id'], $this->productsDefaults);
                break;

            case 'show_settings':
                $this->render('products_form', array('widget' => $data));
                break;

            case 'update_settings':

                $this->load->library('form_validation');
//                $this->form_validation->set_rules('productsType', 'Критерий отбора товаров', 'trim|xss_clean');
                $this->form_validation->set_rules('title', 'Заголовок виджета', 'trim|xss_clean');
                $this->form_validation->set_rules('productsCount', 'Количество товаров для отображения', 'numeric|required');

                if ($this->form_validation->run()) {

                    $productType = implode(',', $this->input->post('productsType'));

                    $settings = array(
                        'productsType' => $productType,
                        'title' => $this->input->post('title'),
                        'productsCount' => $this->input->post('productsCount'),
                        'subpath' => 'widgets'
                    );

                    $this->load->module('admin/widgets_manager')->update_config($data['id'], $settings);
                    showMessage('Сохранение прошло успешно');

                    if ($this->input->post('action') == 'tomain')
                        pjax('/admin/widgets_manager');
                    else
                        pjax('');
                }
                else
                    showMessage($this->form_validation->error_string(), '', 'r');

                break;

            default :
                return false;
                break;
        }
    }

    //end of featured products
    //brands

    public function brands($widget) {
        $settings = $widget[settings];

        $data = array(
            'settings' => $settings,
            'title' => $settings[title],
            'brands' => ShopCore::app()->SBrandsHelper->mostProductBrands($settings[brandsCount], $settings[withImages])
        );

        return $this->template->fetch('widgets/' . $widget['name'], $data);
    }

    public function brands_configure($mode = 'install_defaults', $data = array()) {
        if ($this->dx_auth->is_admin() == FALSE)
            exit;

        switch ($mode) {
            case 'install_defaults':
                $this->load->module('admin/widgets_manager')->update_config($data['id'], $this->brandsDefaults);
                break;

            case 'show_settings':
                $this->render('brands_form', array('widget' => $data));
                break;

            case 'update_settings':

                $this->load->library('form_validation');
                $this->form_validation->set_rules('brandsCount', 'Количество товаров для отображения', 'numeric|required');

                if ($this->form_validation->run()) {
                    $settings = array(
                        'withImages' => (bool) $this->input->post('withImages'),
                        'brandsCount' => $this->input->post('brandsCount'),
                        'subpath' => 'widgets',
                        'title' => $this->input->post('title')
                    );

                    $this->load->module('admin/widgets_manager')->update_config($data['id'], $settings);
                    showMessage('Сохранение прошло успешно');

                    if ($this->input->post('action') == 'tomain')
                        pjax('/admin/widgets_manager');
                    else
                        pjax('');
                }
                else
                    showMessage($this->form_validation->error_string(), '', 'r');

                break;

            default :
                return false;
                break;
        }
    }

    //end of brands
    //

    public function similar_products($widget) {

        $settings = $widget['settings'];
        $data = array(
            'settings' => $settings
        );

        return $this->template->fetch('widgets/' . $widget['name'], $data);
    }

    public function similar_products_configure($mode = 'install_defaults', $data = array()) {
        if ($this->dx_auth->is_admin() == FALSE)
            exit;

        switch ($mode) {
            case 'install_defaults':
                $this->load->module('admin/widgets_manager')->update_config($data['id'], $this->similarDefaults);
                break;

            case 'show_settings':
                $this->render('similar_products_form', array('widget' => $data));
                break;

            case 'update_settings':

                $this->load->library('form_validation');
                $this->form_validation->set_rules('productsCount', 'Количество товаров для отображения', 'numeric|required');

                if ($this->form_validation->run()) {
                    $settings = array(
                        'title' => $this->input->post('title'),
                        'productsCount' => $this->input->post('productsCount'),
                        'subpath' => 'widgets'
                    );

                    $this->load->module('admin/widgets_manager')->update_config($data['id'], $settings);
                    showMessage('Сохранение прошло успешно');

                    if ($this->input->post('action') == 'tomain')
                        pjax('/admin/widgets_manager');
                    else
                        pjax('');
                }
                else
                    showMessage($this->form_validation->error_string(), '', 'r');

                break;

            default :
                return false;
                break;
        }
    }

    //end of brands

    public function render($viewName, array $data = array(), $return = false) {
        if (!empty($data))
            $this->template->add_array($data);

        if ($return === false)
            if ($this->input->is_ajax_request())
                $this->template->display('file:' . 'application/modules/shop/widgets/templates/' . $viewName);
            else
                $this->template->show('file:' . 'application/modules/shop/widgets/templates/' . $viewName);
        else
            return $this->template->fetch('file:' . 'application/modules/shop/widgets/templates/' . $viewName);

        exit;
    }

}

?>
