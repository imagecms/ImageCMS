<?php

namespace Brands;

(defined('BASEPATH')) OR exit('No direct script access allowed');

/**
 * Shop Controller
 *
 * @uses \ShopController
 * @package Shop
 * @copyright 2013 ImageCMS
 * @property model SProducts
 */
class BaseBrands extends \ShopController {

    public $data = null;
    public $model;
    public $brandPath;
    public $templateFile = 'brand';

    public function __construct() {
        parent::__construct();
// Load per page param
        $this->locale = \MY_Controller::getCurrentLocale();

        $this->brandPath = $this->uri->segment($this->uri->total_segments());
// Load per page param
        $this->perPage = $this->input->get('user_per_page')? : \ShopCore::app()->SSettings->frontProductsPerPage;

        $this->model = $this->_loadBrand($this->brandPath);

        if ($this->brandPath == 'brand') {
            $this->core->set_meta_tags('Бренды');
            $this->renderImageList();
//            $this->renderNamesList();
        } else {
            if ($this->model == null)
                $this->core->error_404();
        }

        $this->__CMSCore__();
        $this->index();
        exit;
    }

    /**
     * Display product info.
     *
     * @access public
     */
    public function __CMSCore__() {
        $products = \SProductsQuery::create()
                ->addSelectModifier('SQL_CALC_FOUND_ROWS')
                ->filterByActive(true)
                ->filterByBrandId($this->model->getId())
                ->joinWithI18n($this->locale)
                ->joinProductVariant()
                ->withColumn('IF(sum(shop_product_variants.stock) > 0, 1, 0)', 'allstock')
                ->groupById()
                ->distinct()
                ->orderBy('allstock', \Criteria::DESC);

//for found in categories
        $incategories = clone $products;
        $incategories = $incategories->select(array('CategoryId', 'Id'))->distinct()->find()->toArray();
        if (count($incategories) > 0) {
            foreach ($incategories as $key => $value) {
                unset($incategories[$key]['Id']);
                $incategories[$key] = $value['CategoryId'];
            }
            $incategories = array_count_values($incategories);
        }
        /** Set userPerPage Products Count */
        $this->perPage = (intval(\ShopCore::$_GET['user_per_page'])) ? intval(\ShopCore::$_GET['user_per_page']) : $this->perPage = \ShopCore::app()->SSettings->frontProductsPerPage;

        \ShopCore::app()->SFilter->init($this->model);
        \ShopCore::app()->SFilter->filterGet();

        $products = \ShopCore::app()->SFilter->makePriceFilter($products);
        $products = \ShopCore::app()->SFilter->makePropertiesFilter($products);
        $products = \ShopCore::app()->SFilter->makeCategoriesFilter($products);

//choode order method (default or get)
        if (!\ShopCore::$_GET['order']) {
            $order_method = \Category\BaseCategory::getDefaultSort();
            // $order_method = $order_method->get;
        } elseif (!empty(\ShopCore::$_GET['order'])) {
            $order_method = \ShopCore::$_GET['order'];
        }

        //for order method by get order
        if ($order_method) {
            $products = $products->globalSort($order_method);
        }

        $products = $products->offset((int) \ShopCore::$_GET['per_page'])
                ->limit((int) $this->perPage)
                ->find();

        $priceRange = \ShopCore::app()->SFilter->getPricerange();
        $properties = \ShopCore::app()->SFilter->getProperties();
        $categories = \ShopCore::app()->SFilter->getCategories();

        $totalProducts = $this->getTotalRow();

        $this->core->core_data['data_type'] = 'brand';
        $this->core->core_data['id'] = $this->model->getId();

        $this->data = array(
            'template' => $this->templateFile,
            'model' => $this->model,
            'priceRange' => $priceRange,
            'products' => $products,
            'totalProducts' => $totalProducts,
            'incats' => $incategories,
            //'categories_names' => $cat_names,
            'propertiesInCat' => $properties,
            'categoriesInBrand' => $categories,
            'tree' => \ShopCore::app()->SCategoryTree->getTree(),
            'order_method' => $order_method
        );
    }

    protected function _loadBrand($url) {
        return \SBrandsQuery::create()
                        ->joinWithI18n(\MY_Controller::getCurrentLocale())
                        ->filterByUrl($url)
                        ->findOne();
    }

    private function getTotalRow() {
        $connection = \Propel::getConnection();
        $statement = $connection->prepare('SELECT FOUND_ROWS() as `number`');
        $statement->execute();
        $resultset = $statement->fetchAll();
        return $resultset[0]['number'];
    }

    private function renderImageList() {
        $model = $this->db
                ->join('shop_brands_i18n', 'shop_brands_i18n.id=shop_brands.id')
                ->order_by('name')
                ->where('locale', $this->locale)
                ->get('shop_brands')
                ->result_array();

        $this->render('brands_images', array(
            'model' => $model
        ));
        exit;
    }

    private function renderNamesList() {
        $alphabet = array(
            'А', 'Б', 'В', 'Г', 'Д', 'Е', 'Ё', 'Ж', 'З', 'И', 'Й',
            'К', 'Л', 'М', 'Н', 'О', 'П', 'Р', 'С', 'Т', 'У', 'Ф',
            'Х', 'Ц', 'Ч', 'Ш', 'Щ', 'Э', 'Ю', 'Я', 'A', 'B', 'C',
            'D', 'E', 'F', 'G', 'H', 'I', 'J', 'K', 'L', 'M', 'N',
            'O', 'P', 'Q', 'R', 'S', 'T', 'U', 'V', 'W', 'X', 'Y',
            'Z'
        );

        $array = $this->db
                ->join('shop_brands_i18n', 'shop_brands_i18n.id=shop_brands.id')
                ->order_by('name')
                ->where('locale', $this->locale)
                ->get('shop_brands')
                ->result_array();


        $model = array();
        foreach ($array as $key => $m)
            $model[strtoupper($m[name][0])][$key] = $m;

        $this->render('brands_list', array(
            'model' => $model,
            'alphabet' => $alphabet
        ));
        exit;
    }

}

/* End of file product.php _Admin_ ImageCms */