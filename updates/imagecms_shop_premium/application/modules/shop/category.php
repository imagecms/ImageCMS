<?php

(defined('BASEPATH')) OR exit('No direct script access allowed');

class Category extends \Category\BaseCategory {

    public function __construct() {
        parent::__construct();
    }

    public function index() {
        if ($this->categoryModel->getFullPath() !== $this->categoryPath)
            redirect('shop/category/' . $this->categoryModel->getFullPath(), 'location', '301');
        // Begin pagination
        $this->load->library('Pagination');
        $this->pagination = new SPagination();
        $config['base_url'] = shop_url('category/' . $this->categoryModel->getFullPath() . SProductsQuery::getFilterQueryString());
        $config['page_query_string'] = true;
        $config['total_rows'] = $this->data[totalProducts];
        $config['per_page'] = $this->perPage;
        $config['last_link'] = ceil($this->data[totalProducts]/$this->perPage);
        $config['first_link'] = 1;

        /* --------- */
        $config['next_tag_open'] = '<li>';
        $config['next_tag_close'] = '</li>';

        $this->pagination->num_links = 6;
        $this->pagination->initialize($config);
        $this->data[pagination] = $this->pagination->create_links();
        $this->data[page_number] = $this->pagination->cur_page;
        // End pagination
        /* Seo block */
        //for canonical (another seo block)
        if (isset(\ShopCore::$_GET))
            $this->template->registerCanonical(site_url($this->uri->uri_string()));

        //for canonical (another seo block)
        $this->core->set_meta_tags(
                $this->categoryModel->makePageTitle(), $this->categoryModel->getMetaKeywords(), $this->categoryModel->makePageDesc(), $this->pagination->cur_page, $this->categoryModel->getShowSiteTitle()
        );
        /* Seo block */

        \CMSFactory\Events::create()->registerEvent($this->data, 'category:load');
        \CMSFactory\Events::runFactory();

        $this->render($this->templateFile, $this->data);
        exit;
    }

}

