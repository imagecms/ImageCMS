<?php

if (!defined('BASEPATH'))
    exit('No direct script access allowed');

/**
 * User Profile Controller
 * 
 * @uses ShopController
 * @package Shop
 * @version 0.1
 * @copyright 2010 Siteimage
 * @author <dev@imagecms.net> 
 */
class Profile extends \Profile\BaseProfile {

    protected $_userId = null;

    public function __construct() {
        parent::__construct();
    }

    /**
     * Display list of user order
     * 
     * @access public
     */
    public function index() {
        $this->render($this->data[template], $this->data);
    }

}

/* End of file profile.php */
