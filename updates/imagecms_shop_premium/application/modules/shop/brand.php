<?php

if (!defined('BASEPATH'))
    exit('No direct script access allowed');

/**
 * Shop Brands Controller
 *
 * @uses ShopController
 * @package Shop
 * @version 0.1
 * @copyright 2013 ImageCMS
 * @author <dev@imagecms.net>
 */
class Brand extends \Brands\BaseBrands {

    public function __construct() {
        parent::__construct();
    }

    /**
     * Display list of brand products.
     */
    public function index() {
        
        if ($this->model->getUrl() !== $this->brandPath)
            redirect('shop/brand/' . $this->model->getUrl(), 'location', '301');
        // Begin pagination
        $this->load->library('Pagination');
        $this->pagination = new SPagination();
        $config['base_url'] = shop_url('brand/' . $this->model->getUrl() . '/' . SProductsQuery::getFilterQueryString());
        $config['page_query_string'] = true;
        $config['total_rows'] = $this->data[totalProducts];
        $config['per_page'] = $this->perPage;

        $choice = ceil($config["total_rows"] / $config["per_page"]);
        $config['last_link'] = $choice;
        $config['first_link'] = 1;

        $this->pagination->initialize($config);
        $this->data[pagination] = $this->pagination->create_links();
        $this->data[page_number] = $this->pagination->cur_page;
        // End pagination

        if (isset(ShopCore::$_GET))
            $this->template->registerCanonical(site_url($this->uri->uri_string()));

        $title = $this->model->getMetaTitle() == '' ? $this->model->getName() : $this->model->getMetaTitle();

        if ($this->model->getMetaDescription())
            $description = $this->model->getMetaDescription();
        else
            $description = $this->model->getName();
        $this->core->set_meta_tags($title, $this->model->getMetaKeywords(), $description, $this->pagination->cur_page, 0);

        \CMSFactory\Events::create()->registerEvent($this->data, 'brand:load');
        \CMSFactory\Events::runFactory();

        $this->render($this->data[template], $this->data);
    }

}

/* End of file brand.php */

