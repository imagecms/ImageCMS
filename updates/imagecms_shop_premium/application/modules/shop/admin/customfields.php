<?php

//include '/home/koloda/sites/bigtrucksale/www/bigtracksale/application/modules/shop/models/build/classes/Shop/CustomFieldsQuery.php';
//use \CustomFieldsQuery;

class ShopAdminCustomfields extends ShopAdminController {

    public $defaultLanguage = null;

    public function __construct() {
        parent::__construct();

        $this->defaultLanguage = getDefaultLanguage();
    }

    /**
     * Show list of avaliable custom fields
     * @param type $offset
     * @param type $orderField
     * @param type $orderCriteria
     */
    public function index($offset = 0, $orderField = '', $orderCriteria = '') {
        // echo get_class_methods(CustomFieldsQuery::create());
        $customFields = CustomFieldsQuery::create()->orderByposition()->find();
        $customFieldsCount = $customFields->count();

        $this->render('list', array(
            'customFields' => $customFields,
            'customFieldsCount' => $customFieldsCount,
            'orderField' => $orderField,
            'locale' => $this->defaultLanguage['identif'],
        ));
    }

    /**
     * Create custom field
     */
    public function create() {


        if (!empty($_POST)) {
            //create new field
            $model = new CustomFields;

            $this->form_validation->set_rules($model->rules());

            if ($this->form_validation->run() == FALSE)
                showMessage(validation_errors(), '', 'r');
            else {

                if (!strstr($_POST['Entity'], '_')) 
                    $this->saveModels($model);
                else {
                    $ent_arr = explode('_', $_POST['Entity']);
                    
                    foreach ($ent_arr as $ent) {
                        if (!$model)
                            $model = new CustomFields;
                        
                        $_POST['Entity'] = $ent;

                        $this->saveModels($model);
                        
                        $model = null;
                    }
                }

                showMessage(lang('a_custom_f_create_field'));

//                $action = $_POST['action'];
//                if ($action == 'edit') {
//                    pjax('/admin/components/run/shop/customfields/edit/' . $model->getId());
//                } else {
                    pjax('/admin/components/run/shop/customfields');
//                }
            }
        }
        else
            $this->render('create', array(
                'model' => $model
            ));
    }

    public function saveModels($model) {
        $model->fromArray($_POST);

        if ($_POST['typeId'] == 2) {
            $values = explode(',', $_POST['possible_values']);
            for ($i = 0; $i < count($values); $i++)
                $values[$i] = trim($values[$i]);
            $model->setPossibleValues(serialize($values));
        }
        if ($_POST['is_required'])
            $model->setIsRequired(true);
        else
            $model->setIsRequired(false);

        if ($_POST['is_active'])
            $model->setIsActive(true);
        else
            $model->setIsActive(false);

        if ($_POST['is_private'])
            $model->setIsPrivate(true);
        else
            $model->setIsPrivate(false);

        if ($_POST['multiple_select'] == 'on')
            $model->setOptions('multiple');

        //TODO: change field names to norm ->fromArray() work

        if ($_POST['validators'])
            $model->setValidators($_POST['validators']);

        $model->save();
    }

    /**
     * Edit custom field
     * @param integer $customfieldId    Id of custom field to edit
     */
    public function edit($customfieldId = null) {

        $model = CustomFieldsQuery::create()->findPk((int) $customfieldId);
        if ($model === null)
            $this->error404(lang('a_custom_field_not_found'));
        
        $name = $model->getname();
        if (!empty($_POST)) {
            if ($model->getname() != $this->input->post('name'))
                $this->form_validation->set_rules($model->rules());
            else
                $this->form_validation->set_rules('fLabel', 'Label', 'required');

            if ($this->form_validation->run() == FALSE)
                showMessage(validation_errors(), '', 'r');
            else {
                $type = $model->getTypeId();
                $model->fromArray($_POST);
                $model->setTypeId($type);
                if ($model->gettypeId() == 2) {
                    $values = explode(',', $_POST['possible_values']);
                    for ($i = 0; $i < count($values); $i++)
                        $values[$i] = trim($values[$i]);
                    $model->setPossibleValues(serialize($values));
                }
                if ($_POST['is_required'] == 'on')
                    $model->setIsRequired(true);
                else
                    $model->setIsRequired(false);

                if ($_POST['is_active'] == 'on')
                    $model->setIsActive(true);
                else
                    $model->setIsActive(false);

                if ($_POST['is_private'])
                    $model->setIsPrivate(true);
                else
                    $model->setIsPrivate(false);

                if ($_POST['validators'])
                    $model->setValidators($_POST['validators']);

                $model->save();
                
                if ($model->getEntity() == 'user' or $model->getEntity() == 'order'){
                    $model_concomitant = CustomFieldsQuery::create()->filterByname($name);
                    if ($model->getEntity() == 'user')
                        $model_concomitant = $model_concomitant->filterByEntity('order');
                    else
                        $model_concomitant = $model_concomitant->filterByEntity('user');
                    $model_concomitant = $model_concomitant->findOne();
                    
                    if ($model_concomitant){
                        $model_concomitant->setName($_POST['name']);
                        $model_concomitant->setfLabel($_POST['fLabel']);
                        $model_concomitant->save();
                    }
                }

                showMessage(lang('a_js_edit_save'));

                $action = $_POST['action'];

                if ($action == 'edit') {
                    pjax('/admin/components/run/shop/customfields/edit/' . $customfieldId);
                } else {
                    pjax('/admin/components/run/shop/customfields');
                }
            }
        } else {
            $this->render('edit', array(
                'model' => $model
            ));
        }
    }

    /**
     * delete set of custom fields
     */
    public function deleteAll() {
        if (empty($_POST['ids'])) {
            showMessage(lang('a_del_user_notif'), '', 'r');
            exit;
        }
        if (sizeof($_POST['ids'] > 0)) {
            $model = CustomFieldsQuery::create()
                    ->findPks($_POST['ids']);

            if (!empty($model)) {
                foreach ($model as $order) {
                    $order->delete();
                }

                showMessage(lang('a_custom_f_delete'));
            }
        }
    }

    function change_status_activ($id) {

        $model = CustomFieldsQuery::create()
                ->findPk($id);
        if ($model->getIsActive())
            $model->setIsActive('0');
        else
            $model->setIsActive('1');
        $model->save();
    }

    function change_status_private($id) {

        $model = CustomFieldsQuery::create()
                ->findPk($id);
        if ($model->getIsPrivate())
            $model->setIsPrivate('0');
        else
            $model->setIsPrivate('1');
        $model->save();
    }

    function change_status_required($id) {

        $model = CustomFieldsQuery::create()
                ->findPk($id);
        if ($model->getIsRequired())
            $model->setIsRequired('0');
        else
            $model->setIsRequired('1');
        $model->save();
    }

    public function save_positions() {
        if (!$this->input->post('positions'))
            return false;
        $updates = array();
        foreach ($this->input->post('positions') as $key => $id)
            $updates[] = array('id' => $id, 'position' => $key);
        $this->db->update_batch('custom_fields', $updates, 'id');
        showMessage('Positions saved');
    }

}