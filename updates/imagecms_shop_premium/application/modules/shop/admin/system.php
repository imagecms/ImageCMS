<?php

/**
 * ShopCore class file
 *
 * @package Shop
 * @copyright 2010 Siteimage
 * @author <dev@imagecms.net>
 */
use ImportCSV\ImportBootstrap as Import;

class ShopAdminSystem extends ShopAdminController {

    private $languages = null;
    private $uploadDir = './application/backups/';
    private $csvFileName = 'product_csv_1.csv';
    private $uplaodedFileInfo = array();

    public function __construct() {
        parent::__construct();
        $this->languages = $this->db->get('languages')->result();
        $this->load->helper('file');
    }

    /**
     * Import products from CSV file
     * @return void
     */
    public function import() {
        if (count($_FILES))
            $this->saveCSVFile();
        if (count($_POST['attributes']) && $_POST['csvfile']) {
            $importSettings = $this->cache->fetch('ImportExportCache');
            if (empty($importSettings) || $importSettings['withBackup'] != $this->input->post('withBackup'))
                $this->cache->store('ImportExportCache', array('withBackup' => $this->input->post('withBackup')), '25920000');
            $result = Import::create()->withBackup()->startProcess()->resultAsString();
            echo(json_encode($result));
        } else {
            if (!$_FILES) {
                $importSettings = $this->cache->fetch('ImportExportCache');
                $this->template->assign('withBackup', $importSettings['withBackup']);
                $this->configureImportProcess();
                $this->template->registerJsFile('application/modules/shop/admin/templates/system/importExportAdmin.js', 'after');
                $this->render('import', array(
                    'customFields' => SPropertiesQuery::create()->orderByPosition()->find(),
                    'languages' => $this->languages,
                    'currencies' => SCurrenciesQuery::create()->orderByIsDefault()->find(),
                    'attributes' => ImportCSV\BaseImport::create()->makeAttributesList()->possibleAttributes
                ));
            }
        }

        $this->cache->delete_all();

        if ($_POST[withResize]) {
            $result[content] = explode('/', trim($result[content][0]));
            \MediaManager\Image::create()
                    ->resizeById($result[content])
                    ->resizeByIdAdditional($result[content], TRUE);
        }

        if ($_POST[withCurUpdate])
            \ShopCore::app()->SCurrencyHelper->checkPrices();
    }

    /**
     * Export products to CSV file
     * @return void
     */
    public function export() {
        include './application/modules/shop/classes/PHPExcel.php';
        include './application/modules/shop/classes/PHPExcel/IOFactory.php';
        include './application/modules/shop/classes/PHPExcel/Writer/Excel2007.php';

        ($_POST) or redirect(site_url('admin/components/run/shop/system/import#exportcsv'));
        if ($_POST) {
            $export = new ShopExport(array(
                'attributes' => $_POST['attribute'],
                'attributesCF' => $_POST['cf'],
                'import_type' => trim($_POST['import_type']),
                'delimiter' => trim($_POST['delimiter']),
                'enclosure' => trim($_POST['enclosure']),
                'encoding' => trim($_POST['encoding']),
                'currency' => trim($_POST['currency']),
                'languages' => trim($_POST['language']),
            ));
            $export->export('str');
            if (!$export->hasErrors()) {
                if (!$this->input->is_ajax_request()) {
                    $this->load->helper('download');

                    switch ($_POST['type']) {
                        case "csv": {
                                force_download('price.csv', $export->export('str'));
                                break;
                            }
                        case "xls": {
                                $objPHPExcel = new PHPExcel();
                                foreach ($export->export('array') as $row => $i) {
                                    $p = 0;
                                    foreach ($i as $col => $j) {
                                        $objPHPExcel->getActiveSheet()->setCellValueByColumnAndRow($p, $row + 1, $j);
                                        $p++;
                                    }
                                }
                                $objWriter = PHPExcel_IOFactory::createWriter($objPHPExcel, 'Excel5');
                                $objWriter->save('./application/backups/price.xls');
                                $data = file_get_contents('./application/backups/price.xls');
                                force_download('price.xls', $data);
                                break;
                            }
                        case "xlsx": {
                                $objPHPExcel = new PHPExcel();
                                foreach ($export->export('array') as $row => $i) {
                                    $p = 0;
                                    foreach ($i as $col => $j) {
                                        $objPHPExcel->getActiveSheet()->setCellValueByColumnAndRow($p, $row + 1, $j);
                                        $p++;
                                    }
                                }
                                $objWriter = PHPExcel_IOFactory::createWriter($objPHPExcel, 'Excel2007');
                                $objWriter->save('./application/backups/price.xlsx');
                                $data = file_get_contents('./application/backups/price.xlsx');
                                force_download('price.xlsx', $data);
                                break;
                            }
                        default : {
                                force_download('price.csv', $export->export('str'));
                                break;
                            }
                    }
                }
            } else {
                echo $this->processErrors($export->getErrors());
            }
        }
    }

    private function saveCSVFile() {
        $this->takeFileName();

        $this->load->library('upload', array(
            'max_size' => '10240',
            'overwrite' => true,
            'upload_path' => $this->uploadDir,
            'allowed_types' => 'csv|xls|xlsx'));
        if ($this->upload->do_upload('userfile')) {
            $data = $this->upload->data();
            if (($data['file_ext'] === '.xls') || ($data['file_ext'] === '.xlsx')) {
                $this->convertXLStoCSV($data['full_path']);
                unlink('./application/backups/' . $data['client_name']);
            } else {
                rename('./application/backups/' . $data['client_name'], './application/backups/' . $this->csvFileName);
            }

            $this->configureImportProcess();
        }
        else
            echo json_encode(array('error' => \ImportCSV\Factor::ErrorFolderPermission));
    }

    private function convertXLStoCSV($excel_file = '') {
        include './application/modules/shop/classes/PHPExcel.php';
        include './application/modules/shop/classes/PHPExcel/IOFactory.php';
        include './application/modules/shop/classes/PHPExcel/Writer/Excel2007.php';
        $objReader = PHPExcel_IOFactory::createReaderForFile($excel_file);
        $objReader->setReadDataOnly(true);
        $objPHPExcel = $objReader->load($excel_file);
        $sheetData = $objPHPExcel->getActiveSheet()->toArray(null, true, true, true);

        foreach ($sheetData as $i) {
            foreach ($i as $j) {
                $toPrint .= '"' . str_replace('"', '""', $j) . '";';
            }
            $toPrint .= PHP_EOL;
        }
        $filename = $this->csvFileName;
        fopen('./application/backups/' . $filename, 'w+');
        if (is_writable('./application/backups/' . $filename)) {
            if (!$handle = fopen('./application/backups/' . $filename, 'w+')) {
                echo json_encode(array('error' => \ImportCSV\Factor::ErrorFolderPermission));
                exit;
            }

            write_file('./application/backups/' . $filename, $toPrint);

            fclose($handle);
        } else {
            showMessage("Файл $filename недоступен для записи");
        }
    }

    private function configureImportProcess($vector = true) {
        if (file_exists($this->uploadDir . $this->csvFileName)) {
            $file = fopen($this->uploadDir . $this->csvFileName, 'r');
            $row = array_diff(fgetcsv($file, 10000, ";", '"'), array(null));
            fclose($file);
            $this->getFilesInfo();
            foreach ($this->uplaodedFileInfo as $file)
                $uploadedFiles[str_replace('.', '', $file['name'])] = date('d.m.y H:i', $file['date']);
            if ($vector && $this->input->is_ajax_request() && $_FILES)
                echo json_encode(array(
                    'success' => true,
                    'row' => $row,
                    'attributes' => \ImportCSV\BaseImport::create()->attributes,
                    'filesInfo' => $uploadedFiles
                ));
            else
                $this->template->add_array(array(
                    'rows' => $row,
                    'attributes' => \ImportCSV\BaseImport::create()->makeAttributesList()->possibleAttributes,
                    'filesInfo' => $uploadedFiles
                ));
        }
    }

    private function takeFileName() {
        $fileNumber = (in_array($_POST['csvfile'], array(1, 2, 3))) ? intval($_POST['csvfile']) : 1;
        $this->csvFileName = "product_csv_$fileNumber.csv";
    }

    public function getAttributes() {
        $this->takeFileName();
        $this->configureImportProcess(false);
        $this->render('import_attributes');
    }

    private function getFilesInfo($dir = null) {
        $dir = ($dir == null) ? $this->uploadDir : $dir;
        foreach (get_filenames($dir) as $file) {
            if (strpos($file, 'roduct_csv_')) {
                $this->uplaodedFileInfo[] = get_file_info($this->uploadDir . $file);
            }
        }
    }

    /**
     *
     *
     */
    public function exportUsers() {
        if (empty($_POST['export'])) {

            showMessage(lang('a_exp_users_systeam_failed'), '', 'r');
            exit;
        }
        if ($_POST['export'] == 'csv') {
            $this->load->helper('download');
            $model = SUserProfileQuery::create()
                    ->find();

            $fp = fopen('./uploads/exportUsers.csv', 'w');
            if ($fp === false) {

                redirect('/admin/components/run/shop/users/index#export');
            }

            foreach ($model as $u) {
                fwrite($fp, "\"" . $u->getUserEmail() . "\",\"" . $u->getName() . "\"\n");
            }
            fseek($fp, 0);

            fclose($fp);


            $data = file_get_contents("./uploads/exportUsers.csv");
            $name = 'exportUsers.csv';

            force_download($name, $data);
        } elseif ($_POST['export'] == 'monkey') {

            $settings = &ShopCore::app()->SSettings;
            $model = SUserProfileQuery::create()
                    ->find();

            if ($settings->adminMessageMonkey && $settings->adminMessageMonkeylist) {
                $config = array('apikey' => $settings->adminMessageMonkey, 'secure' => FALSE);

                $this->load->library('MCAPI', $config, 'mail_chimp');

                foreach ($model as $u) {

                    $this->mail_chimp->listSubscribe($settings->adminMessageMonkeylist, $u->getUserEmail());
                }
                pjax('/admin/components/run/shop/users/index');
                showMessage(lang('a_exp_users_systeam_succes'));
            } else {
                pjax('/admin/components/run/shop/users/index#export');
                showMessage(lang('a_mh_error_sys_m') . $settings->adminMessageMonkeylist, '', 'r');
            }
        }


//return false;
    }

    /**

     * Create html box with errors.
     *
     * @param  array $errors Errors array
     * @return string
     */
    protected function processErrors(array $errors) {
        $result = '';
        foreach ($errors as $err) {
            $result .= $err . '<br/>';
        }

        return '<p class="errors">' . $result . '</p>';
    }

    /**
     * Check uploaded file extension
     *
     * @return boolean
     */
    protected function checkFileExtension($fileName) {
        $parts = explode('.', $fileName);

        if (end($parts) != 'csv') {
            return false;
        } else {
            return true;
        }
    }

}
