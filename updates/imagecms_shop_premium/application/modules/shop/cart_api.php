<?php

(defined('BASEPATH')) OR exit('No direct script access allowed');

/**
 * CartApi Controller
 *
 * @uses ShopController
 * @uses \Cart\BaseCart
 * @package Shop
 * @version 1,1
 * @copyright 2013 ImageCMS
 * @author <dev@imagecms.net>
 */
class Cart_api extends \Cart\BaseCart {

    public function __construct() {
        parent::__construct();
//        ($this->input->is_ajax_request()) OR $this->core->error_404();
    }

    /**
     * @access public
     * @copyright 2013 ImageCMS
     * @author <dev@imagecms.net>
     */
    public function index() {
        $this->core->error_404();
    }

    /**
     * Add product to cart from POST data.
     * @param string $instance
     * @access public
     * @return JSON
     * @author <dev@imagecms.net>
     * @copyright (c) 2013 ImageMCMS
     */
    public function add($instance = 'SProducts') {
        if (TRUE === parent::add($instance)) {
            $response = array('success' => true, 'errors' => false);
        } else {
            $response = array('success' => false, 'errors' => true, 'message' => $this->errorMessages);
        }
        return json_encode($response);
    }

    /**
     * Remove product from cart by ID.
     * @param int $id
     * @return bool
     * @access public
     * @author <dev@imagecms.net>
     * @copyright (c) 2013 ImageMCMS
     */
    public function delete($id) {
        if (parent::delete($id)) {
            $response = array('success' => true, 'errors' => false);
        } else {
            $response = array('success' => false, 'errors' => true, 'message' => $this->errorMessages);
        }
        return json_encode($response);
    }

    /**
     * Recount cart items
     * @author <dev@imagecms.net>
     * @copyright (c) 2013 ImageMCMS
     * @return JSON
     */
    public function recount() {
        try {
            ($this->input->post('recount') == 1) OR throwException('API, You are drunk, go home!');
            $response = array('success' => true, 'errors' => false);

            /** Recount items */
            $item = ShopCore::app()->SCart->apiRecount();
            if ($item)
                $response['count'] = $item['quantity'];

            /** Return result as JSON */
            return json_encode($response);
        } catch (\Exception $exc) {
            $this->errorMessages = $exc->getMessage();
            $response = array('success' => false, 'errors' => true, 'message' => $this->errorMessages);
            return json_encode($response);
        }
    }

    /**
     * Sync cart data with front
     * @return JSON
     * @access public
     * @author <dev@imagecms.net>
     * @copyright (c) 2013 ImageMCMS
     */
    public function sync() {
        $response = array();

        /** Load products from cart */
        $items = ShopCore::app()->SCart->loadProducts();
        foreach ($items as $item) {
            if ($item['instance'] == 'SProducts') {
                $var = SProductVariantsQuery::create()->findPk($item['variantId']);
                if ($var){
                    $var_photo = $var->getSmallPhoto();
                    $var_num = $var->getNumber();
                    $var_stock = $var->getStock();
                    
                }
                $response['cartItem_' . $item['productId'] . '_' . $item['variantId']] = array(
                    'id' => $item['productId'],
                    'vId' => $item['variantId'],
                    'price' => $item['price'],
                    'name' => $item['model']->getName(),
                    'vname' => $item['variantName'],
                    'count' => $item['quantity'],
                    'maxcount' => $var_stock,
                    'number' => $var_num,
                    'url' => shop_url('product/' . $item['model']->getUrl()),
                    'img' => $var_photo,
                );
            } else {
                $response['cartItem_' . $item['kitId']] = array(
                    'count' => $item['quantity'],
                    'kit' => true
                );
            }
        }

        return json_encode(array('success' => true, 'errors' => false, 'data' => array('items' => $response)));
    }

    /**
     * Clear Cart data
     * @return JSON
     * @access public
     * @author <dev@imagecms.net>
     * @copyright (c) 2013 ImageMCMS
     */
    public function clear() {
        ShopCore::app()->SCart->removeAll();
        return json_encode(array('success' => true, 'errors' => false));
    }

    /**
     * Get Gift Certificate
     * @access public
     * @author <dev@imagecms.net>
     * @copyright (c) 2013 ImageMCMS
     * @return JSON
     */
    public function getGiftCert() {
        try {
            /** Is correct request? */
            (($this->input->post('giftcert')) && ($this->input->post('giftcert') != NULL)) OR throwException('dasdas');

            $certUsage = $this->db->where('gift_cert_key', $this->input->post('giftcert'))->get('shop_orders')->num_rows();

            if ($certUsage == 0) {
                $select_cert = $this->db->where('key =', $this->input->post('giftcert'))
                        ->where('active =', 1)
                        ->get('shop_gifts', 1)
                        ->row_array();
            }
            if ($this->input->post('checkCert') == 1) {
                $response = array('success' => true, 'errors' => false);
                if ($select_cert != null AND $certUsage == 0)
                    $response['cert_price'] = $select_cert['price'];
                else {
                    $response['cert_price'] = 0;
                    $response['errors'][] = 'Not valid certificate';
                }
                return json_encode($response);
            }
        } catch (\Exception $exc) {
            $response = array(
                'success' => FALSE,
                'errors' => TRUE,
                'message' => $exc->getMessage()
            );
            return json_encode($data);
        }
    }

    /**
     * Get Payment Methods by ID
     * @param int $deliveryId
     * @return JSON
     * @author <dev@imagecms.net>
     * @copyright (c) 2013 ImageCMS
     */
    public function getPaymentsMethods($deliveryId) {
        $paymentMethods = ShopDeliveryMethodsSystemsQuery::create()->filterByDeliveryMethodId($deliveryId)->find();
        foreach ($paymentMethods as $paymentMethod) {
            $paymentMethodsId[] = $paymentMethod->getPaymentMethodId();
        }
        $paymentMethod = SPaymentMethodsQuery::create()->filterByActive(true)->where('SPaymentMethods.Id IN ?', $paymentMethodsId)->orderByPosition()->find();

        $jsonData = array();
        foreach ($paymentMethod->getData() as $pm) {
            $jsonData[] = array(
                'id' => $pm->getId(),
                'name' => $pm->getName()
            );
        }

        echo json_encode($jsonData);
    }

}

/* End of file cart_api.php */