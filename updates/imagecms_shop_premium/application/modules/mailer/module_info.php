<?php if (!defined('BASEPATH')) exit('No direct script access allowed');

$com_info = array(
	'menu_name'   => 'Модуль подписки и рассылки.',                                            
	'description' => 'Модуль подписки и рассылки на новости, акции, скидки.',                  
	'admin_type'  => 'inside',         
	'window_type' => 'xhr',            
        'w'           => 600,              
	'h'           => 550,              
	'version'     => '1.0',            
	'author'      => 'dev@imagecms.net'
);

/* End of file module_info.php */
