<?php if (!defined('BASEPATH')) exit('No direct script access allowed');

$com_info = array(
	'menu_name'   => 'Поиск',
	'description' => '',                
	'admin_type'  => 'inside',            
	'window_type' => 'xhr',               
        'w'           => 600,                 
	'h'           => 550,                 
	'version'     => '0.1',             
	'author'      => 'dev@imagecms.net'
);

/* End of file module_info.php */
