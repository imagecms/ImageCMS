$(document).ready(function() {

    /*IMPORT EXPORT*/
    $('#importcsvfile').die('live').live('change', function() {
        var selector = $(this).closest('form');
        $chekedFile = $('input[name=csvfile]:checked').val();
        selector.append('<input type="hidden" name="csvfile" value="' + $chekedFile + '"/>');
        $(selector).validate()
        if ($(selector).valid()) {
            var options = {
                success: function(data) {
                    try {
                        var obj = JSON.parse(data);
                        if (obj.error)
                            showMessage('Ошибка', obj.error);
                        if (obj.success == true) {
                            showMessage('Успешно', 'Файл загружен. Слот ' + $chekedFile);
                            if (obj.filesInfo.product_csv_1csv != '')
                                $('span[data-file=product_csv_1csv]').text(obj.filesInfo.product_csv_1csv);
                            if (obj.filesInfo.product_csv_2csv != '')
                                $('span[data-file=product_csv_2csv]').text(obj.filesInfo.product_csv_2csv);
                            if (obj.filesInfo.product_csv_3csv != '')
                                $('span[data-file=product_csv_3csv]').text(obj.filesInfo.product_csv_3csv);
                            loadCsvAttributes($chekedFile);
                        }
                    } catch (e) {
                    }
                    return true;
                }
            };
            $(selector).ajaxSubmit(options);
        }
    });
    $('input[name=csvfile]').die('live').live('change', function() {
        loadCsvAttributes($(this).val());
    })

    $('#makeImportForm').die('live').live('submit', function() {
        $chekedFile = $('input[name=csvfile]:checked').val();
        $names = '';
        $('.attrnameHolder').each(function(index) {
            $names = $names + $(this).attr('data-attrnames') + ',';
        })
        $('input[type=hidden].attributes').val($names);
        $('input[type=hidden].slothidden').val($chekedFile);
        $.ajax({
            url: "/admin/components/run/shop/system/import",
            type: 'post',
            data: $(this).serialize(),
            success: function(obj) {
                buildImportReport(obj);
            }
        });
        return false;
    });
    function buildImportReport($obj) {
        try {
            $object = jQuery.parseJSON($obj);
            if ($object.error != null)
                showMessage('', $object.message);
            else if ($object.success != null) {
                showMessage('', $object.message);
            }
        }
        catch (err) {
            showMessage('', 'Ошибка в работе скрипта. Сообщите администратору.');
        }
//                $('.importProcess').fadeOut(100);
//                $('.importRaport').fadeIn(100);
    }

    $('.dropdown-attr a').die('live').live('click', function() {
        $startPoint = $(this).closest('div');
        $name = $(this).text();
        $attname = $(this).attr('data-attname');
        $names = '';
        $startPoint
                .find('.attrnameHolder')
                .text($name)
                .attr('data-attrnames', $attname)
                .end()
                .find('button')
                .attr('title', $name);
    })
    function loadCsvAttributes(val)
    {
        $.ajax({
            url: "/admin/components/run/shop/system/getAttributes",
            type: 'post',
            data: 'csvfile=' + val,
            success: function(data) {
                $('.attrHandler').html(data);
            }
        });
    }

    $(".runExport").die('live').live("click", function() {

        $this = $('#makeExportForm');
        $.ajax({
            url: "/admin/components/run/shop/system/export",
            type: "post",
            data: $this.serialize(),
            success: function(msg) {
                if (msg == '')
                    $this.submit();
                else
                    showMessage("", msg);
            }
        });
    });
    /**/
});
