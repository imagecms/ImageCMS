<?php

/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
    $lang['content']		=	'Content';
    $lang['category']		=	'Category';
    $lang['']			=	'Нет';
    $lang['create_cat']		=	'Create category';
    $lang['title']		=	'Title';
    $lang['prev_cont']		=	'Pre content';
    $lang['full_cont']		=	'Full content';
    $lang['param']		=	'Settings';
    $lang['trans_title']	=	'Title transliteration';
    $lang['just_lat']		=	'only Latin characters';
    $lang['tags']		=	'Tags';
    $lang['gen_desc']		=	'Generate description';
    $lang['gen_key_words']	=	'Generate keywords';
    $lang['main_tpl']		=	'Main template';
    $lang['by_default']		=	'By default';
    $lang['page_tpl']		=	'Page template';
    $lang['comm_alow']		=	'Allow comments';
    $lang['show_sett']		=	'show settings';
    $lang['sett']		=	'Settings'; 
    $lang['hide']		=	'hide';
    $lang['pub_stat']		=	'Publication status';
    $lang['published']		=	'Published';
    $lang['wait_approve']	=	'Waiting for approve';
    $lang['not_publ']		=	'Not published';
    $lang['date_and_time_cr']	=	'Date and time of create';
    $lang['date_and_time_p']	=	'Date and time of publication';
    $lang['access']		=	'Access';
    $lang['all']		=	'All';
    $lang['additional_fields']  =	'Additional fields';
    $lang['image']              =	'Image';
    $lang['create']             =	'Create';
?>
