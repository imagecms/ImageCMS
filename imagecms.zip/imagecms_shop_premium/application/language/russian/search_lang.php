<?php
$lang['sr_product_o'] = 'товар';
$lang['sr_product_t'] = 'товара';
$lang['sr_product_tr'] = 'товаров';
$lang['sr_product_found'] = 'Найдено';