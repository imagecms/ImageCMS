 <?php
/*
/var/www/image.loc/templates/newLevel/js/jquery.equalhorizcell.min.js
/var/www/image.loc/templates/newLevel/js/css3-mediaqueries.min.js
/var/www/image.loc/templates/newLevel/js/jquery.fancybox-1.3.4.pack.js
/var/www/image.loc/templates/newLevel/js/_jquery.jcarousel.min.js
/var/www/image.loc/templates/newLevel/js/_jquery.mousewheel.js
/var/www/image.loc/templates/newLevel/js/jquery-1.8.3.min.js
/var/www/image.loc/templates/newLevel/js/_jquery.lazyload.js
/var/www/image.loc/templates/newLevel/js/_jquery.jscrollpane.min.js
/var/www/image.loc/templates/newLevel/js/_jquery.imagecms.shop.js
/var/www/image.loc/templates/newLevel/js/cloud-zoom.1.0.3.min.js
/var/www/image.loc/templates/newLevel/js/localStorageJSON.js
/var/www/image.loc/templates/newLevel/js/sp_ll_jc_mw_icms_us_scripts.js
/var/www/image.loc/templates/newLevel/js/_jquery.equalhorizcell.js
/var/www/image.loc/templates/newLevel/js/_scripts.js
/var/www/image.loc/templates/newLevel/js/raphael-min.js
/var/www/image.loc/templates/newLevel/js/_underscore-min.js*/

echo " <script> langs = {};
 </script>"; 
?>