/*
 * Translated default messages for the jQuery validation plugin.
 * Locale: RU (Russian; русский язык)
 */
(function ($, langs) {
	$.extend($.validator.messages, {
            	required: langs.needToFillField,
		remote: langs.please + ", " + langs.enterCorrectValue +  ".",
		email: langs.please + ", " + langs.enterValidEmailAddress + ".",
		url: langs.please + ", " + langs.enterCorrectURL + ".",
		date: langs.please +  ", " + langs.enterCorrectDate + ".",
		dateISO: langs.please +  ", " + langs.enterCorrectDateFormatISO + ".",
		number: langs.please +  ", " + langs.enterNumber + ".",
		digits: langs.please + ", " + langs.enterOnlyNumbers + ".",
		creditcard: langs.please +  ", " + langs.enterValidCreditCardNumber + ".",
		equalTo: langs.please +  ", " + langs.enterTheSameValueAgain + ".",
		accept:  langs.please + ", " + langs.selectFileWwithCorrectExtension + ".",
		maxlength: $.validator.format(langs.please +  ", " + langs.enterNoMore + " {0} " + langs.characters + "."),
		minlength: $.validator.format(langs.please +  ", " + langs.enterAtLeast + " {0} " + langs.characters + "."),
		rangelength: $.validator.format(langs.please +  ", " + langs.enterValueFrom + " {0} " + langs.to + " {1} " + langs.characters + "."),
		range: $.validator.format(langs.please +  ", " + langs.enterNumberFrom + "{0} " + langs.to + " {1}."),
		max: $.validator.format(langs.please + ", " + langs.enterNumberLessThanOrEqualTo + " {0}."),
		min: $.validator.format(langs.please +  ", " + langs.enterNumberMoreThanOrEqualTo + " {0}.")
	});
}(jQuery, lang));