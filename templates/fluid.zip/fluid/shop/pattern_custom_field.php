<label for="{$inputId}">
    <span class="title">
        <span class="p_r">
            {$label}
            {$requiredHtml}
        </span>
    </span>
    <span class="frame-form-field">
        {$input}
    </span>
</label>