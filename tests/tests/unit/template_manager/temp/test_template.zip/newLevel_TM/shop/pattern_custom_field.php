<label for="{$inputId}">
    <span class="title">{$label}:</span>
    <span class="frame-form-field">
        {$input}{$requiredHtml}
    </span>
</label>