<?php
/*
/var/www/image.loc/application/modules/found_less_expensive/assets/js/scripts.js*/

echo " <script> langs = {}; langs['Fill in required fields!'] = lang('Fill in required fields!', 'found');
langs['Invalid email!'] = lang('Invalid email!', 'found');
langs['Sent! Thanks for the notification!'] = lang('Sent! Thanks for the notification!', 'found');
 </script>"; 
?>