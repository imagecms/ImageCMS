<?php
/*
/var/www/image.loc/templates/administrator/js/pjax/jquery.pjax.min.js
/var/www/image.loc/templates/administrator/js/jquery-validate/jquery.validate.min.js
/var/www/image.loc/templates/administrator/js/jquery-validate/additional-methods.min.js
/var/www/image.loc/templates/administrator/js/jquery-validate/jquery.validate.i18n.js
/var/www/image.loc/templates/administrator/js/jquery-validate/additional-methods.js
/var/www/image.loc/templates/administrator/js/jquery-validate/messages_ru.js
/var/www/image.loc/templates/administrator/js/jquery-dialog/jquery-ui-1.7.3.custom.min.js
/var/www/image.loc/templates/administrator/js/jquery-dialog/jquery.ui.core.min.js
/var/www/image.loc/templates/administrator/js/jquery-dialog/jquery.ui.widget.min.js
/var/www/image.loc/templates/administrator/js/jquery-dialog/jquery-1.3.2.min.js
/var/www/image.loc/templates/administrator/js/jquery-dialog/jquery-ui-1.8.23.custom.min.js
/var/www/image.loc/templates/administrator/js/jquery-dialog/jquery-1.8.0.min.js
/var/www/image.loc/templates/administrator/js/jquery-dialog/jquery.ui.dialog.min.js
/var/www/image.loc/templates/administrator/js/jquery-dialog/jquery.ui.position.min.js
/var/www/image.loc/templates/administrator/js/jquery-dialog/jquery-ui-1.8.23.custom.js*/

echo " <script> langs = {}; langs['This field is required'] = ". lang('This field is required', 'admin') .";
langs['Please fix this field.'] = ". lang('Please fix this field.', 'admin') .";
langs['Enter a valid email address.'] = ". lang('Enter a valid email address.', 'admin') .";
langs['Please enter a valid URL.'] = ". lang('Please enter a valid URL.', 'admin') .";
langs['Please enter a valid date.'] = ". lang('Please enter a valid date.', 'admin') .";
langs['Please enter a valid date (ISO).'] = ". lang('Please enter a valid date (ISO).', 'admin') .";
langs['Please enter a valid number.'] = ". lang('Please enter a valid number.', 'admin') .";
langs['Please enter only digits.'] = ". lang('Please enter only digits.', 'admin') .";
langs['Please enter a valid credit card number.'] = ". lang('Please enter a valid credit card number.', 'admin') .";
langs['Please enter the same value again.'] = ". lang('Please enter the same value again.', 'admin') .";
langs['Please enter a value with a valid extension.'] = ". lang('Please enter a value with a valid extension.', 'admin') .";
langs['Please enter no more than {0} characters.'] = ". lang('Please enter no more than {0} characters.', 'admin') .";
langs['Please enter at least {0} characters.'] = ". lang('Please enter at least {0} characters.', 'admin') .";
langs['Please enter a value between {0} and {1} characters long.'] = ". lang('Please enter a value between {0} and {1} characters long.', 'admin') .";
langs['Please enter a value between {0} and {1}.'] = ". lang('Please enter a value between {0} and {1}.', 'admin') .";
langs['Please enter a value less than or equal to {0}.'] = ". lang('Please enter a value less than or equal to {0}.', 'admin') .";
langs['Please enter a value greater than or equal to {0}.'] = ". lang('Please enter a value greater than or equal to {0}.', 'admin') .";
 </script>"; 
?>