<?php
/*
/var/www/image.loc/application/modules/mod_discount/assets/js/main.js
/var/www/image.loc/application/modules/mod_discount/assets/js/adminScripts.js*/

echo " <script> langs = {}; langs['Status changed'] = ". lang('Status changed', 'mod_discount') .";
langs['Discount deleted'] = ". lang('Discount deleted', 'mod_discount') .";
 </script>"; 
?>