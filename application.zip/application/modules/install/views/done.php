<h2><?php echo lang('Installation complete', 'install') ?>.</h2>
<p>
<a href="<?php echo site_url('admin') ?>"><?php echo lang('Go to Control Panel', 'install') ?></a>
    <br/>
<a href="<?php echo site_url('') ?>"><?php echo lang('Main page', 'install')?></a>
</p>
