<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed');
/*
| -------------------------------------------------------------------------
| URI ROUTING
| -------------------------------------------------------------------------
 */

$route['install'] = 'install/index';
$route['install/step_1'] = 'install/step_1';
$route['install/step_2'] = 'install/step_2';
$route['install/done'] = 'install/done';
$route['install/install/done'] = 'install/done';

