<?php
/*
/var/www/image.loc/application/modules/cmsemail/assets/js/email.js*/

echo " <script> langs = {}; langs['4444dd'] = ". lang('4444dd', 'cmsemail') .";
langs['Error'] = ". lang('Error', 'cmsemail') .";
langs['Variable is not removed'] = ". lang('Variable is not removed', 'cmsemail') .";
langs['Message'] = ". lang('Message', 'cmsemail') .";
langs['Variable successfully removed'] = ". lang('Variable successfully removed', 'cmsemail') .";
langs['Error'] = ". lang('Error', 'cmsemail') .";
langs['Variable is not updated'] = ". lang('Variable is not updated', 'cmsemail') .";
langs['Message'] = ". lang('Message', 'cmsemail') .";
langs['Variable successfully updated'] = ". lang('Variable successfully updated', 'cmsemail') .";
langs['Error'] = ". lang('Error', 'cmsemail') .";
langs['Variable is not added'] = ". lang('Variable is not added', 'cmsemail') .";
langs['Message'] = ". lang('Message', 'cmsemail') .";
langs['Variable successfully added'] = ". lang('Variable successfully added', 'cmsemail') .";
langs['Message'] = ". lang('Message', 'cmsemail') .";
langs['Variable must be surrounded by $'] = ". lang('Variable must be surrounded by $', 'cmsemail') .";
langs['Message'] = ". lang('Message', 'cmsemail') .";
langs['Variable must have a value'] = ". lang('Variable must have a value', 'cmsemail') .";
 </script>"; 
?>