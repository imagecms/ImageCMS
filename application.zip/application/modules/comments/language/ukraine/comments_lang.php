<?php

$lang['login_for_comments']  = 'Только авторизованные пользователи могут оставлять комментарии. <a href="%s" class="loginAjax">Авторизуйтесь</a>, пожалуйста.';
$lang['lang_total_comments'] = 'Всего комментариев: ';
$lang['lang_comment_text']   = 'Комментарий';
$lang['lang_comment_button'] = 'Написать &rarr;';
$lang['lang_comment_author'] = 'Ваше имя';
$lang['lang_comment_email']  = 'Почта';
$lang['lang_comment_site']  = 'Сайт';
$lang['lang_logged_in_as']   = 'Вы вошли как';

$lang['error_comments_period'] = 'Разрешается комментировать раз в %s минут.';
$lang['error_comments_text']   = 'Заполните текст комментария.';
$lang['error_wrong_mail']      = 'Заполните правильный email.';
$lang['error_comments_diabled']= 'Комментирование этой записи запрещено.';
$lang['post_comment'] = 'Оставить комментарий';

?>
