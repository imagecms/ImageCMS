<?php
/*
/var/www/image.loc/application/modules/exchangeunfu/assets/js/exchangeunfu.js
/var/www/image.loc/application/modules/exchangeunfu/assets/js/admin.js*/

echo " <script> langs = {}; langs['Not choose'] = lang('Not choose', 'exchangeunfu');
langs['Not choose'] = lang('Not choose', 'exchangeunfu');
langs['Error'] = lang('Error', 'exchangeunfu');
langs['Can not create a price twice for partner'] = lang('Can not create a price twice for partner', 'exchangeunfu');
langs['Message'] = lang('Message', 'exchangeunfu');
langs['Upgrade successful.'] = lang('Upgrade successful.', 'exchangeunfu');
langs['Message'] = lang('Message', 'exchangeunfu');
langs['Successful deleting.'] = lang('Successful deleting.', 'exchangeunfu');
langs['Message'] = lang('Message', 'exchangeunfu');
langs['Value is changed.'] = lang('Value is changed.', 'exchangeunfu');
langs['Message'] = lang('Message', 'exchangeunfu');
langs['Value is changed.'] = lang('Value is changed.', 'exchangeunfu');
langs['Message'] = lang('Message', 'exchangeunfu');
langs['Value is changed.'] = lang('Value is changed.', 'exchangeunfu');
langs['Message'] = lang('Message', 'exchangeunfu');
langs['Partner updated'] = lang('Partner updated', 'exchangeunfu');
langs['Message'] = lang('Message', 'exchangeunfu');
langs['Partner successfully deleted'] = lang('Partner successfully deleted', 'exchangeunfu');
langs['Message'] = lang('Message', 'exchangeunfu');
langs['Partner not deleted'] = lang('Partner not deleted', 'exchangeunfu');
langs['Message'] = lang('Message', 'exchangeunfu');
langs['Partner successfully added'] = lang('Partner successfully added', 'exchangeunfu');
langs['Error'] = lang('Error', 'exchangeunfu');
langs['Partner not added'] = lang('Partner not added', 'exchangeunfu');
 </script>"; 
?>