<?php

if (!defined('BASEPATH'))
    exit('No direct script access allowed');

$com_info = array(
    'menu_name' => '1C exchange',
    'description' => 'Модуль для 1C импорта/експорта',
    'admin_type' => 'inside',
    'window_type' => 'xhr',
    'w' => 600,
    'h' => 550,
    'version' => '1.0',
    'author' => 'a.gula@imagecms.net'
);

/* End of file module_info.php */
