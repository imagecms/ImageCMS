<?php if (!defined('BASEPATH')) exit('No direct script access allowed');

$com_info = array(
	'menu_name'   => lang('Filter', 'filter'),     
	'description' => lang('Search pages and categories to add. fields', 'filter'),                  
	'admin_type'  => 'window',            
	'window_type' => 'xhr',               
        'w'           => 600,                 	
        'h'           => 550,                 
	'version'     => '0.1',               
	'author'      => 'dev@imagecms.net' 
);

/* End of file module_info.php */
