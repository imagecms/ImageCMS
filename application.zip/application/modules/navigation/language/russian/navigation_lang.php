<?php

$lang['Brands'] = 'Бренды';
$lang['Compare'] = 'Список сравнения';
$lang['Wish_list'] = 'Список желаний';
$lang['Profile']  = 'Личний кабинет';
$lang['Cart']  = 'Корзина';

?>
