<?php

$lang['Brands'] = 'Brands';
$lang['Compare'] = 'Compare';
$lang['Wish_list'] = 'Wish List';
$lang['Profile']  = 'Profile';
$lang['Cart']  = 'Cart';

?>
