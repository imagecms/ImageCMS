ALTER TABLE  `settings` ADD  `backup` TEXT NOT NULL;
