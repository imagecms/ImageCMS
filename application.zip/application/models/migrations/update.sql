ALTER TABLE  `settings` ADD  `update` TEXT CHARACTER SET utf8 COLLATE utf8_general_ci;

