/var/www/image.loc/application/language/js.php<?php
/*
./assets/js/jquery_ui.js
./assets/js/wishlist.js*/

echo " <script> lang = {}; lang['303c4f9b5a45da2e2b0cad904f06b3a5'] =  ". _('dsdsdsds2').";
lang['71ca9079d08bfa85e1e803427d25205a'] =  ". _('yyyy').";
 </script>"; 
?>